"""
with open("students.csv") as file:

    for line in file:
        name, place  = line.rstrip().split(",")
        print(f"{name} is in {place}")

"""

students = []

with open("students.csv") as file:
    for line in file:
        name, place = line.rstrip().split(",")
        students.append(f"{name} is in {place}")

for student in sorted(students):
    print(student)
