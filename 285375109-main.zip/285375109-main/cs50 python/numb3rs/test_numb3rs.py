import re
from numb3rs import validate

def test_range():

    assert validate("127.0.0.1") == True
    assert validate("255.255.255.255") == True
    assert validate("512.512.512.512") == False
    assert validate("1.1.1.256") == False

def test_type():
    assert validate("cat") == False
    assert validate("127.0.0.1") == True
    assert validate("000.001.010.100") == False
