import sys

"""
their is another way

if len(sys.argv) < 2:
    print("too few arguments")
elif len(sys.argv) > 2:
       print("too many argument")
else:
       print("hello i m", sys.argv[1])
       """

"""
sys.exit is use upper too to aviod the error
"""

"""
try:
        print("hello i m ", sys.argv[1])
except IndexError:
        sys.exit("your on worng location")

"""

if len(sys.argv) <2:
    sys.exit("too few arguments")

for arg in sys.argv[1:]:
    print("hey i m", arg)
