class Cat:
    x = 3

    def meow(self):
        for _ in range(Cat.x):
            print("meow")


cat = Cat()
cat.meow()
