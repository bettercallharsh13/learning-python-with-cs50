import json
from datetime import datetime


class User:
    def __init__(self, name, age, height, weight, sleep, water):
        self.name = name
        self.age = age
        self.height = height
        self.weight = weight
        self.sleep = sleep
        self.water = water


class HealthAnalyzer:
    def __init__(self, user):
        self.user = user

    def bmi(self):
        return self.user.weight / ((self.user.height / 100) ** 2)

    def bmi_status(self):
        bmi = self.bmi()

        if bmi < 18.5:
            return "Underweight"
        elif bmi < 25:
            return "Normal"
        elif bmi < 30:
            return "Overweight"
        return "Obese"

    def health_score(self):
        score = 100

        bmi = self.bmi()

        if bmi < 18.5 or bmi > 25:
            score -= 15

        if self.user.sleep < 7:
            score -= 10

        if self.user.water < 2:
            score -= 10

        return max(score, 0)

    def recommendations(self):
        tips = []

        if self.bmi() > 25:
            tips.append("Increase physical activity.")

        if self.user.sleep < 7:
            tips.append("Sleep at least 7-9 hours.")

        if self.user.water < 2:
            tips.append("Drink more water.")

        return tips

    def ai_insight(self):
        bmi = self.bmi()

        return (
            f"{self.user.name} has a BMI of {bmi:.1f}. "
            f"Current health score is {self.health_score()}/100. "
            f"Improving sleep and hydration may improve overall wellness."
        )


def save_report(data):
    try:
        with open("history.json", "r") as file:
            history = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        history = []

    history.append(data)

    with open("history.json", "w") as file:
        json.dump(history, file, indent=4)


def main():
    name = input("Name: ")
    age = int(input("Age: "))
    height = float(input("Height (cm): "))
    weight = float(input("Weight (kg): "))
    sleep = float(input("Sleep Hours: "))
    water = float(input("Water Intake (L): "))

    user = User(name, age, height, weight, sleep, water)

    analyzer = HealthAnalyzer(user)

    report = {
        "date": str(datetime.now()),
        "name": user.name,
        "bmi": round(analyzer.bmi(), 2),
        "status": analyzer.bmi_status(),
        "score": analyzer.health_score()
    }

    save_report(report)

    print("\n===== HEALTH REPORT =====")
    print(f"BMI: {analyzer.bmi():.2f}")
    print(f"Status: {analyzer.bmi_status()}")
    print(f"Health Score: {analyzer.health_score()}/100")

    print("\nRecommendations:")
    for tip in analyzer.recommendations():
        print("-", tip)

    print("\nAI Insight:")
    print(analyzer.ai_insight())


if __name__ == "__main__":
    main()
