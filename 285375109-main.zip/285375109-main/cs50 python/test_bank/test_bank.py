from bank import value

def test_hello():
    assert value("hello, world") == 0
    assert value("hello, harsh") == 0
    assert value("hello, amit") == 0
    assert value("HELLO, WORLD") == 0

def test_h():
    assert value("hry, amit") == 20
    assert value("hry, harsh") == 20

def test_other():
    assert value("yoo, world") == 100
    assert value("yoo, harsh") == 100
    assert value("yoo, amit") == 100
