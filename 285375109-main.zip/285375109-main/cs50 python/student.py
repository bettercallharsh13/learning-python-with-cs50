
class Student:

    #def __init__(self, name, house, subject):

    def __init__(self, name, house):
        if not name:
            raise ValueError("Missing name")

        #if house not in ["bhopal", "indore"]:
            #raise ValueError("worng place")
        self.name = name
        self.house = house
        #self.subject = subject


    def __str__(self):
        return f"{self.name} from {self.house}"

    @classmethod
    def get(cls):
        name = input("Name: ")
        house = input("House: ")
        return cls(name, house)


"""
    def charm(self):
        match self.subject:
            case "hindi":
                return "boooo"
            case "maths":
                return "yeee"
            case "physcis":
                return "ohooo"
"""
"""
    @property
    def house(self):
        return self._house
    @house.setter
    def house(self, house):
        if house not in ["indore", "bhopal"]:
            raise ValueError("Invalid house")

        self._house = house
"""



def main():
    student = Student.get()
    print(student)
    #print(student.charm())


    #print(f"{student.name} from {student.house}")
    #print(student)
"""
def get_student():
    name = input("Name: ")
    house = input("House: ")
    #subject = input("Subject: ")
    #return Student(name, house, subject)
    return Student(name, house)
"""

"""
    student = Student()
    student.name = input("Name: ")
    student.house = input("House: ")
    return student
"""
"""
    student = {}
    student["name"] = input("Name: ")
    student["house"] = input("House: ")
    return student
"""
"""
    name = input("Name: ")
    house = input("House: ")
    return {"name": name, "house": house}
"""
if __name__ == "__main__":
    main()

