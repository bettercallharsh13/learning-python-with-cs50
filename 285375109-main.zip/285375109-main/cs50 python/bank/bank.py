"""
text = input("Greeting : ").lower()

if "hello" in text:
    print("$0")
elif text.startswith("h") and "hello" not in text:
    print("$20")
else:
    print("$100")
"""
def main():
    greet = input("Input: ")
    print(f"${value(greet)}")



def value(greeting):
    greeting = ""
    if greeting.startswith("hello"):
        return 0
    elif greeting.startswith("h"):
        return 20
    else:
        return 100



if __name__ == "__main__":
    main()
