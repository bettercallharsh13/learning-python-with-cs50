import random

cards = ["harsh", "amit", "jack"]


def main():
    random.seed(1)
    print(random.choices(cards, k=2))

    """
    print(random.choices(cards, weights = [100, 0, 0], k=2))
"""


main()
