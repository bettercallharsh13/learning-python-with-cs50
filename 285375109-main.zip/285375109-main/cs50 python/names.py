"""
names = []

for _ in range(3):
    names.append(input("whats your name: "))
for name in sorted(names):
    print(f"hello, {name}")
"""
"""
name = input("what's your name: ")
with open("names.txt", "a") as file:
    file.write(f"{name}\n")
"""
#file.close()
"""
with open("names.txt", "r") as file:
    lines = file.readline()

for line in lines:
    print("hello,", line.rstrip())
    """
"""
with open("names.txt", "r") as file:
    for line in file:
        print("hello,", line.rstrip())
"""

names = []
with open("names.txt") as file:
    """
    for line in sorted(file):
        print("hello,", line.rstrip())
        """


    for line in file:
        names.append(line.rstrip())

for name in sorted(names):
    print(f"hello, {name}")
