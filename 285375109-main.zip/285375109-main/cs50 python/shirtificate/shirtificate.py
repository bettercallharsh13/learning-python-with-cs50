from fpdf import FPDF

name = input("Name: ")

pdf = FPDF()
pdf.add_page()


pdf.set_font("Helvetica", style="B", size=16)
pdf.cell(0, 20 , "CS50 Shirtificate", align="C")
pdf.ln(20)

pdf.image("shirtificate.png", x=10, y=50, w=190)


pdf.set_xy(0, 140)
pdf.set_font("Helvetica", "B", 24)
pdf.set_text_color(255, 255, 255)
pdf.cell(210, 10, f"{name} took CS50", align="C")

pdf.output("shirtificate.pdf")



