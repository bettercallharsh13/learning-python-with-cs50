from um import count

def test_count():
    assert count("um") == 1
    assert count("UM") == 1
    assert count("um?") == 1
    assert count("um, thanks for the album") == 1

