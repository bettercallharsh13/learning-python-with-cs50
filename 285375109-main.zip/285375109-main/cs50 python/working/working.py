import re



def main():

        print(convert(input("Hours: ")))

def convert(s):
    match = re.search(
    r"^(\d{1,2})(?::(\d{2}))? (AM|PM) to (\d{1,2})(?::(\d{2}))? (AM|PM)$", s)
    if not match:
         raise ValueError
    start_hour = int(match.group(1))
    start_minute = int(match.group(2) or 0)
    start_period = match.group(3)

    end_hour = int(match.group(4))
    end_minute = int(match.group(5) or 0)
    end_period = match.group(6)

    if not (1 <= start_hour <= 12 and 1 <= end_hour <= 12):
        raise ValueError

    if not (0 <= start_minute <= 59 and 0 <= end_minute <= 59):
        raise ValueError

    start = convert_time(start_hour, start_minute, start_period)
    end = convert_time(end_hour, end_minute, end_period)

    return f"{start} to {end}"


def convert_time(hour, minute, period):

    if period == "AM":
        if hour == 12:
            hour = 0

    else:
        if hour != 12:
            hour += 12
    return f"{hour:02}:{minute:02}"




if __name__ == "__main__":
    main()
