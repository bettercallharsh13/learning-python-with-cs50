import random
class Hat:
    house = ["indore", "bhopal"]
    """
    def __init__(self):
        self.house = ["indore", "bhopal"]
    """
    @classmethod
    def sort(cls, name):

        print(name, "is in ", random.choice(cls.house))


Hat.sort(input(">"))
