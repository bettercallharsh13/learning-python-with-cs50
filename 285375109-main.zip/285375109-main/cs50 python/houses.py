students = [
    {"name": "harsh", "house": "gryfindor"},
    {"name": "harry", "house": "gryfindor"},
    {"name": "amit", "house": "peak"},
    {"name": "draco", "house": "slytherin"},
    {"name": "ron", "house": "ravenclaw"},

]

houses = set()
for i in students:
    houses.add(students["houses"])

for house in houses:
    print(house)

