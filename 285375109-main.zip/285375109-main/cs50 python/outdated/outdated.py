months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

while True:
    try:
        date = input("Date: ").strip()
        if "/" in date:
            month , day , year = date.split("/")
            month = int(month)
            day = int(day)
            year = int(year)

        else:
            month , day , year = date.split(" ")

            if not day.endswith(",") :
                continue
            if month not in months:
                continue

            month = months.index(month) + 1
            year = int(year)
            day = int(day[:-1])

        if not (1 <= month <= 12 and 1 <= day <= 31):
            continue
        print(f"{year}-{month:02}-{day:02}")
        break

    except (ValueError, EOFError):
        pass
