from calculator import square


def test_square():
    assert square(2) == 4
    assert square(3) == 9
    assert square(-2) == 4
    assert square(-3) == 9
    assert square(0) == 0
"""
def main():
    test_square()


def test_square():
    try:
        assert square(2) == 4
    except AssertionError:
        return print("it's worng 2 = 4")

    try:

        assert square(3) == 9
    except AssertionError:
        return print("it's worng 3 = 9")
"""
"""
    if square(2) != 4:
        print("2 square is not 4")
    if square(3) != 9:
        print("3 square is not 9")
"""

"""
if __name__ == "__main__":
    main()
"""
