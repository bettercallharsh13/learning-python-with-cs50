from datetime import date
import inflect
import sys

p = inflect.engine()

def main():
    birthdate = input("Date of Birth: ")

    try:
        birth = date.fromisoformat(birthdate)
    except ValueError:
        sys.exit("Invalid date")

    print(convert(birth))


def convert(birth):
    today = date.today()
    minutes = (today - birth).days * 24 *60

    return f"{p.number_to_words(minutes,andword="").capitalize()} minutes"



if __name__ == "__main__":
    main()
