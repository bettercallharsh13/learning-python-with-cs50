"""
try:
    email = input("what's your email ? ").strip()

    username, domain = email.split("@")

    if username and domain.endswith(".edu" or ".com"):
        print("Valid")
    else:
        print("Invalid")
except ValueError:
    print("Worng input")
"""
import re

email = input("what's your email ? ").strip()

#if re.search("..*@..*", email):
#if re.search(r".+@.+\.edu", email):
#if re.search(r"^.+@.+\.edu$", email):
#if re.search(r"^[^@].+@[^@].+\.edu$", email):
#if re.search(r"^[a-zA-Z1-9_].+@[a-zA-Z1-9_].+\.edu$", email):
if re.search(r"^\w+@\w+\.edu$", email):

    print("Valid")
else:
    print("Invalid")
